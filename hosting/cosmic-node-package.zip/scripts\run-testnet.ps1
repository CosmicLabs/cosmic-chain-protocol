# Testnet-1 PowerShell Script
# This script runs the cosmic-node with Testnet-1 configuration

param(
    [int]$TestDuration = 0  # 0 means run indefinitely
)

# Set UTF-8 encoding to prevent emoji garbling in logs
chcp 65001
$OutputEncoding = [Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)

Write-Host "COSMIC NODE TESTNET-1 LAUNCHER" -ForegroundColor Cyan
Write-Host "===============================" -ForegroundColor Cyan
Write-Host ""

# Clean up previous test data
Write-Host "Cleaning up previous test data..." -ForegroundColor Yellow
if (Test-Path "data\testnet1") { 
    Remove-Item -Recurse -Force "data\testnet1" 
}
if (Test-Path "logs\testnet1") { 
    Remove-Item -Recurse -Force "logs\testnet1" 
}

# Create directories
New-Item -ItemType Directory -Path "data\testnet1" -Force | Out-Null
New-Item -ItemType Directory -Path "logs\testnet1" -Force | Out-Null

Write-Host "[OK] Test directories created" -ForegroundColor Green

# Define paths
$NodePath = "cosmic-node"
$ConfigPath = "configs/testnet1.toml"
$NodeUrl = "http://localhost:8081"

# Check if config file exists
if (-not (Test-Path $ConfigPath)) {
    Write-Host "Error: Config file not found at $ConfigPath" -ForegroundColor Red
    exit 1
}

# Function to check if node is running
function Test-NodeRunning {
    try {
        $response = Invoke-WebRequest -Uri "$NodeUrl/status" -Method GET -TimeoutSec 5
        return $true
    } catch {
        return $false
    }
}

# Start the node
Write-Host "Starting cosmic-node with Testnet-1 configuration..." -ForegroundColor Yellow
Write-Host "Config: $ConfigPath" -ForegroundColor Gray
Write-Host "Data directory: ./data/testnet1" -ForegroundColor Gray
Write-Host "Logs directory: ./logs/testnet1" -ForegroundColor Gray
Write-Host ""

# Build and run the node
$process = Start-Process -FilePath "cargo" -ArgumentList "run", "--bin", "cosmic-node", "--", "--config", $ConfigPath -PassThru -NoNewWindow

# Wait for node to start
Write-Host "Waiting for node to start..." -ForegroundColor Yellow
Start-Sleep -Seconds 5

# Check if node is running
if (Test-NodeRunning) {
    Write-Host "[OK] Node is running!" -ForegroundColor Green
    Write-Host "API endpoint: $NodeUrl" -ForegroundColor Cyan
    Write-Host "Explorer: $NodeUrl/explorer" -ForegroundColor Cyan
    Write-Host "Metrics: $NodeUrl/metrics" -ForegroundColor Cyan
    Write-Host ""
    
    # Display network info
    try {
        $status = Invoke-RestMethod -Uri "$NodeUrl/status" -Method GET
        Write-Host "Network Status:" -ForegroundColor Cyan
        Write-Host "  Height: $($status.height)" -ForegroundColor White
        Write-Host "  ERA: $($status.era)" -ForegroundColor White
        Write-Host "  Reward: $($status.reward)" -ForegroundColor White
        Write-Host ""
    } catch {
        Write-Host "Could not fetch status: $($_.Exception.Message)" -ForegroundColor Yellow
    }
} else {
    Write-Host "[ERROR] Node failed to start!" -ForegroundColor Red
    exit 1
}

# Run for specified duration or indefinitely
if ($TestDuration -gt 0) {
    Write-Host "Running for $TestDuration seconds..." -ForegroundColor Yellow
    Start-Sleep -Seconds $TestDuration
    
    # Stop the node
    Write-Host "Stopping node..." -ForegroundColor Yellow
    Stop-Process -Id $process.Id -Force
    Write-Host "[OK] Node stopped" -ForegroundColor Green
} else {
    Write-Host "Node is running indefinitely. Press Ctrl+C to stop." -ForegroundColor Yellow
    Write-Host "You can also stop it with: Stop-Process -Id $($process.Id) -Force" -ForegroundColor Gray
    
    # Keep script running
    try {
        while ($process.HasExited -eq $false) {
            Start-Sleep -Seconds 5
        }
    } catch {
        Write-Host "Script interrupted" -ForegroundColor Yellow
    }
}