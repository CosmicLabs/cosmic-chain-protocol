# Cosmic Testnet Node Package

This package contains everything you need to run a Cosmic Testnet node and participate in mining.

## Package Contents

- `bin/cosmic-node.exe` - The Cosmic node executable
- `configs/testnet1.toml` - Testnet configuration file
- `scripts/run-testnet.ps1` - PowerShell script to run the node
- `scripts/run-testnet.sh` - Shell script to run the node

## System Requirements

- Windows 10/11, macOS, or Linux
- At least 4GB RAM
- At least 20GB free disk space

## Installation Instructions

1. Extract this package to a directory of your choice
2. Make sure you have the necessary dependencies installed (Rust toolchain is not required as this is a pre-compiled binary)

## Running the Node

### Windows

Open PowerShell as Administrator and navigate to the package directory, then run:

```powershell
.\scripts\run-testnet.ps1
```

### macOS/Linux

Open a terminal and navigate to the package directory, then run:

```bash
chmod +x scripts/run-testnet.sh
./scripts/run-testnet.sh
```

## Configuration

The node uses the `configs/testnet1.toml` configuration file. You can modify this file to change node settings, but the default configuration should work for most users.

## Mining

To participate in mining, you'll need to:

1. Run the node using the instructions above
2. Register as a miner through the portal
3. Obtain an API key for authentication
4. Configure your mining software to connect to your node

## Troubleshooting

If you encounter any issues:

1. Check that your system meets the minimum requirements
2. Ensure you have the latest version of this package
3. Check the logs in the `logs` directory (created automatically when running the node)
4. Visit our Discord server for community support

## Updating

To update to a new version:

1. Download the latest node package
2. Backup your data directory if you want to keep your node state
3. Replace the files in this package with the new ones
4. Restart your node

## License

This software is licensed under the MIT License. See the LICENSE file for details.