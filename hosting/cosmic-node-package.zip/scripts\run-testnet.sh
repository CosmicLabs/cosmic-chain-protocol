#!/bin/bash

# Testnet-1 Shell Script
# This script runs the cosmic-node with Testnet-1 configuration

# Set variables
TEST_DURATION=${1:-0}  # First argument or 0 (indefinite)
CONFIG_PATH="configs/testnet1.toml"
NODE_URL="http://localhost:8081"

echo "COSMIC NODE TESTNET-1 LAUNCHER"
echo "==============================="
echo ""

# Clean up previous test data
echo "Cleaning up previous test data..."
rm -rf data/testnet1
rm -rf logs/testnet1

# Create directories
mkdir -p data/testnet1
mkdir -p logs/testnet1

echo "[OK] Test directories created"

# Check if config file exists
if [ ! -f "$CONFIG_PATH" ]; then
    echo "Error: Config file not found at $CONFIG_PATH"
    exit 1
fi

# Function to check if node is running
check_node_running() {
    curl -s -f -m 5 "$NODE_URL/status" > /dev/null 2>&1
    return $?
}

# Start the node
echo "Starting cosmic-node with Testnet-1 configuration..."
echo "Config: $CONFIG_PATH"
echo "Data directory: ./data/testnet1"
echo "Logs directory: ./logs/testnet1"
echo ""

# Build and run the node in background
cargo run --bin cosmic-node -- --config "$CONFIG_PATH" > logs/testnet1/node.log 2>&1 &
NODE_PID=$!

# Wait for node to start
echo "Waiting for node to start..."
sleep 5

# Check if node is running
if check_node_running; then
    echo "[OK] Node is running!"
    echo "API endpoint: $NODE_URL"
    echo "Explorer: $NODE_URL/explorer"
    echo "Metrics: $NODE_URL/metrics"
    echo ""
    
    # Display network info
    if STATUS=$(curl -s "$NODE_URL/status"); then
        echo "Network Status:"
        HEIGHT=$(echo "$STATUS" | grep -o '"height":[0-9]*' | cut -d: -f2)
        ERA=$(echo "$STATUS" | grep -o '"era":[0-9]*' | cut -d: -f2)
        REWARD=$(echo "$STATUS" | grep -o '"reward":"[^"]*"' | cut -d'"' -f4)
        echo "  Height: $HEIGHT"
        echo "  ERA: $ERA"
        echo "  Reward: $REWARD"
        echo ""
    else
        echo "Could not fetch status"
    fi
else
    echo "[ERROR] Node failed to start!"
    echo "Check logs in logs/testnet1/node.log for details"
    exit 1
fi

# Run for specified duration or indefinitely
if [ "$TEST_DURATION" -gt 0 ]; then
    echo "Running for $TEST_DURATION seconds..."
    sleep "$TEST_DURATION"
    
    # Stop the node
    echo "Stopping node..."
    kill "$NODE_PID"
    echo "[OK] Node stopped"
else
    echo "Node is running indefinitely. Press Ctrl+C to stop."
    echo "You can also stop it with: kill $NODE_PID"
    
    # Wait for the node process
    wait "$NODE_PID"
fi